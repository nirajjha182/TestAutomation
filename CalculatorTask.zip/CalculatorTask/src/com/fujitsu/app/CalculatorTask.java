package com.fujitsu.app;

import java.util.Scanner;

import com.fujitsu.util.Calculator;
import com.fujitsu.util.Validator;

/**
 * Simple  calculator 
 * @author GhoshSu
 *
 */
public class CalculatorTask {

	public static void main(String[] args) {

		// Step 1 ( Take 3 user input, firstNumber, secondNumber, operator
		// Step 2 ( Initialize Validator class to validate user input )
		String firstNumber;
		String secondNumber;
		String operator;
		Scanner userInput = new Scanner(System.in);
		System.out.println("==============[Simple Arithmetic Calculator]============");
		System.out.println("Please enter 1st number : ");
		firstNumber= userInput.next();
		System.out.println("Please enter 2nd number : ");
		secondNumber= userInput.next();
		System.out.println("Please select the operation you want to perform [+,-,*,/,&,=] : ");
		operator= userInput.next();
		
		
		
		
		Validator validator = new Validator(firstNumber, secondNumber, operator);
	
		boolean inputcheck =validator.isValidInput(firstNumber, secondNumber, operator);
		if (inputcheck==false){
			validator.displayValidatonErrors();}
		else{
			Calculator calculator = new Calculator (validator.getFirstNumber(),validator.getSecondNumber(),validator.getOperatorString());
			calculator.doCalculation();
			calculator.displayResult();
		}
	
		
		// IF validation passed 
			//initialize Calculator class like below
		// IF Validation failed
		// show validaton messages 
	}
}

