package com.fujitsu.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.fujitsu.app.AppConst;

/**
 * User input validator class
 * @author GhoshSu
 *
 */
public class Validator {

	private String firstNumber;
	private String secondNumber;
	private String operatorString;
	private List<String> validatonErrors = null;
	boolean voperator;
	Scanner validateInput = new Scanner(System.in);

	public Validator (String firstnumStr, String secondNumStr, String operatorStr ) {
			this.firstNumber=firstnumStr;
			this.secondNumber=secondNumStr;
			this.operatorString=operatorStr;
		
	}
	
	/**
	 * Check all user input
	 * @return
	 */
	public boolean isValidInput(String firstnumStr, String secondNumStr, String operatorStr) {
		// If Validation failed, store all validation error messages in the validatonErrors list
	
			validatonErrors =new ArrayList<String>();
			String decimalPattern = "^-?[0-9]\\d*(\\.\\d+)?$"; 
			String numericPattern = "([0-9]*)";  
			boolean fnumber = false;
			boolean snumber = false;
			
			if (firstnumStr.matches(decimalPattern)==true || firstnumStr.matches(numericPattern) ==true){
			fnumber = true;}
			
			if (secondNumStr.matches(decimalPattern)==true || secondNumStr.matches(decimalPattern) == true)  {
			snumber=true;}
			
			if (fnumber==false || snumber == false)	{				
			validatonErrors.add("1st and 2nd Number should be Numeric. Input you have given is " + firstnumStr + " and " + secondNumStr + "." );}
						
			if(AppConst.allowedOperators.contains(operatorStr)==true)		
			{
			validatonErrors.add(operatorStr + " is not valid operator. Please input operator within the allowed range ( +, -, *, /, &, =) ");
				if(operatorStr.equalsIgnoreCase("/")==true && secondNumStr.equalsIgnoreCase("0")==true)
				{
					validatonErrors.add("[Your Input has error] Division by Zero : You can't Divide by Zero!!! ");
				}
			}
		
			
			if (validatonErrors.size()==0){return true;}
			else {return false;}
		
	}
	
	public void displayValidatonErrors() {		
			for(int i=0;i<validatonErrors.size();i++){
			System.out.println(validatonErrors.get(i));}		
	}

	public double getFirstNumber() {
			return Double.parseDouble(this.firstNumber);}

	public double getSecondNumber() {
			return Double.parseDouble(this.secondNumber);}

	public String getOperatorString() {
			return this.operatorString;}
}
