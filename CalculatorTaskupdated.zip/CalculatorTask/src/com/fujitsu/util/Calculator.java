package com.fujitsu.util;

/**
 * All arithmetic calculation will be performed within this class.
 * @author GhoshSu
 *
 */
public class Calculator {

	private double firstNumber;
	private double secondNumber;
	private String operator;
	private String finalresult;
	private double result;
	private String compareval;
	
	/**
	 * Argument constructor 
	 * @param firstNum
	 * @param secondNum
	 * @param operator
	 */
	public Calculator(double firstNum, double secondNum, String operator ) {
		this.firstNumber = firstNum;
		this.secondNumber = secondNum;
		this.operator = operator;
		
	}
	
	/**
	 * Main mathematical calculator method will be called from CalculatorTask.
	 * @return
	 */
	public String doCalculation() {
		if (this.operator.equalsIgnoreCase("+"))
		{
			finalresult=this.firstNumber + " + " + this.secondNumber + " = " + Double.toString(doAddition());					
		}
		else if(this.operator.equalsIgnoreCase("-"))
		{
			finalresult=this.firstNumber + " - " + this.secondNumber + " = " + Double.toString(doSubstraction());
		}
		else if(this.operator.equalsIgnoreCase("*"))
		{
			finalresult=this.firstNumber + " * " + this.secondNumber + " = " + Double.toString(doMult());
		}
		else if(this.operator.equalsIgnoreCase("/"))
		{
			finalresult=this.firstNumber + " / " + this.secondNumber + " = " + Double.toString(doDiv());
		}
		else if(this.operator.equalsIgnoreCase("="))
		{
			finalresult=doComparison();
		}
		else if(this.operator.equalsIgnoreCase("&"))
		{
			finalresult=this.firstNumber + " & " + this.secondNumber + " = " +Double.toString(doBitwiseAnd());
		}
		return finalresult;
	}
	
	/**
	 * Will display the calculated result 
	 */
	public void displayResult() {
		String displayRes = doCalculation();
		System.out.println("******Result*****" + "\n" + displayRes);
	}
	
	private double doAddition() {
		result= this.firstNumber+this.secondNumber;
		return result;}
	
	private double doSubstraction() {
		 result= this.firstNumber-this.secondNumber;
		 return result;}
	
	private double doMult() {
		result= this.firstNumber*this.secondNumber;
		return result;}
	
	private double doDiv() {
		result= this.firstNumber/this.secondNumber;
		return result;}
	
	/**
	 * Please convert double to int using type casting 
	 * e.g int firtNum = (int) this.firstNumber
	 * int value = (int) 45.187;
	 * value will become = 45
	 * @return
	 */
	private int doBitwiseAnd() {
		result= (int)this.firstNumber & (int)this.secondNumber;
		return  (int)result;}
	
	/**
	 * Calculation for = operator 
	 * @return String
	 */
	private String doComparison() {		
		if (this.firstNumber==this.secondNumber){
			compareval = this.firstNumber + " == " + this.secondNumber;}
		else if(this.firstNumber > this.secondNumber){
			 compareval = this.firstNumber + " > " + this.secondNumber;}
		else if((this.firstNumber<this.secondNumber)){
			 compareval = this.firstNumber + " < " + this.secondNumber;}
		return compareval;}
}
